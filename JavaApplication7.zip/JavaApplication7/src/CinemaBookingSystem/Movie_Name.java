
package CinemaBookingSystem;


public interface Movie_Name 
{

   public String getMovieName() ;
   public void SetMovieName(String M);
}
