
package CinemaBookingSystem;

import java.time.LocalDateTime;


public class Ticket implements Movie_Name
{
    private float Price;
    private LocalDateTime date;
    private int SerialNumber;
    private int SeatNumber;
    private String MovieName;
    
public Ticket(){}
    public Ticket(float Price, LocalDateTime date, int SerialNumber, int SeatNumber) {
        this.Price = Price;
        this.date = date;
        this.SerialNumber = SerialNumber;
        this.SeatNumber = SeatNumber;
    }

    public float getPrice() {
        return Price;
    }

    public void setPrice(float Price) {
        this.Price = Price;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public int getSerialNumber() {
        return SerialNumber;
    }

    public void setSerialNumber(int SerialNumber) {
        this.SerialNumber = SerialNumber;
    }

    public int getSeatNumber() {
        return SeatNumber;
    }

    public void setSeatNumber(int SeatNumber) {
        this.SeatNumber = SeatNumber;
    }
    
     @Override
    public void SetMovieName(String M)
    {
    MovieName = M;
    }
     @Override
      public String getMovieName(){
          return MovieName;
      }
}
