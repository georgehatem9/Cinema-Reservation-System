
package CinemaBookingSystem;


public class Poster implements Movie_Name {
    private String PosterId;
    private String Gener;
    private String MovieName;

    public Poster( String Gener) 
    {
        
        this.Gener = Gener;
    }

    public String getGener() {
        return Gener;
    }

    public void setGener(String Gener) {
        this.Gener = Gener;
    }
    public void setposterid(String x){
        this.PosterId=x;  
    }
    public String getPosterid(){
        return this.PosterId;
    }
    @Override
    public boolean equals(Object o){
        if(o == this)
            return true;
        Poster x=(Poster)o;
        if(x.PosterId==this.PosterId)
            return true;
        return false;
    }
    @Override
    public void SetMovieName(String M)
    {
    MovieName = M;
    }
     @Override
      public String getMovieName(){
          return MovieName;
      }
    }

