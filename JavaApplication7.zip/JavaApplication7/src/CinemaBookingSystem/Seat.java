
package CinemaBookingSystem;


public class Seat {
   private int seatNumber;
   boolean avilable =true;
    public Seat(int seatNumber) {
        this.seatNumber = seatNumber;
    }
    public void bookSeat(){
        this.avilable=false;
    }
    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }
   
  
}

