package CinemaBookingSystem;


public class Movie implements Movie_Name
{
    private String Gener;
    private String Duration;
    private float Rating;
    private String Language;
    private String MovieName;
private float ticketprice;
    public Movie(String Gener, String Duration, float Rating, String Language) 
    {
        this.Gener = Gener;
        this.Duration = Duration;
        this.Rating = Rating;
        this.Language = Language;
    }

    public float getRating() {
        return Rating;
    }

    public void setRating(float Rating) {
        this.Rating = Rating;
    }

    public String getGener() {
        return Gener;
    }

    public float getPrice(){
        return this.ticketprice; 
    }
    public void setPrice(Float x)
    {
        this.ticketprice=x;
    }
    public void setGener(String Gener) {
        this.Gener = Gener;
    }

    public String getDuration() {
        return Duration;
    }

    public void setDuration(String Duration) {
        this.Duration = Duration;
    }

    public String getLanguage() {
        return Language;
    }

    public void setLanguage(String Language) 
    {
        this.Language = Language;
    }
      @Override
    public void SetMovieName(String M)
    {
    MovieName = M;
    }
     @Override
      public String getMovieName(){
          return MovieName;
      }
       @Override
    public boolean equals(Object o){
        if(o == this)
            return true;
        Movie x=(Movie)o;
        if(x.MovieName==this.MovieName)
            return true;
        return false;
    }
}
