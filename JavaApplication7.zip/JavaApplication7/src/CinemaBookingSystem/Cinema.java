
package CinemaBookingSystem;

import java.util.ArrayList;
import java.util.List;


public class Cinema {
    List<Hall> Halls = new ArrayList<>();
    List<Poster> Posters = new ArrayList<>();
    List<Movie> Movies = new ArrayList<>();
    List<Employee> Employees = new ArrayList<>();
    List<Store> Stores = new ArrayList<>();
    List<Advertisement> Advertisements = new ArrayList<>();
public void removeMovie(String Movien){
    for(Movie x:Movies){
        if(x.equals(Movien))
            Movies.remove(x);
    }
}
public void AddMovie(Movie x){
    Movies.add(x);
}
public void AddHall(Hall Hallx) {
          Halls.add(Hallx);
        }
public void removeHall(Hall Hallx){
    for(Hall x:Halls){
        if(x.equals(Hallx)){
            Halls.remove(x);
            break;
        }
    }
}
public void Addposter(Poster posterx) {
          Posters.add(posterx);
        }
public void Removeposter(Poster posterx) {
    for(Poster x:Posters){
        if(x.equals(posterx)){
            Posters.remove(x);
            break;
        }
    }
 } 
public void AddStores(Store storex){
          Stores.add(storex);      
  }
public void RemoveStore(Store storex) {
    for(Store x:Stores){
        if(x.equals(storex)){
            Stores.remove(x);
            break;
        }
    }
 }
public void AddAdv(Advertisement x){
    Advertisements.add(x);
}
public void RemoveAdv(Advertisement x){
    for(Advertisement z:Advertisements){
        if(x.equals(z))
            Advertisements.remove(z);
    }
}
public void AddEmployee(Employee x){
    Employees.add(x);   
}
public void RemoveEmployee(Employee x){
    for(Employee z:Employees){
        if(x.equals(z))
            Employees.remove(z);
    }
}
}