
package CinemaBookingSystem;
import java.util.ArrayList;
import java.util.List;


public class Customer extends Person 
{
    private String preferences;

     List<String> Preferences = new ArrayList<String>();
    public Customer(String preferences, String Name, String phone_Num)
    {
        super(Name, phone_Num);
        this.preferences = preferences;
    }

    public boolean check_Preferences(String p) //deh 3shan a check 3la ale by7bo
    {
        
        if (preferences == p )
        {
            Preferences.add(p);
            return true;
        }
        return false;
    }

    public String getPreferences() // deh 3shan a3rf kol customer by7b eh
    {
        return preferences;
    }

    public void setPreferences(String preferences) {
        this.preferences = preferences;
    }
            
}

   

