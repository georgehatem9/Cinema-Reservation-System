
package CinemaBookingSystem;


public class Worker extends Employee
{
    private String department;

    public Worker(String department, int id, float salary, float working_hours, String Name, String phone_Num) {
        super(id, salary, working_hours, Name, phone_Num);
        this.department = department;
    }
    
@Override
    public final void  CalculateSalary(float p) 
    {
       this.setSalary(p*this.getWorking_hours());
       
    }    

    public String getDepartment() 
    {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
