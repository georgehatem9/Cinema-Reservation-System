
package CinemaBookingSystem;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class Caisher extends Employee
{
  public int Sold_Tickets=0;
  List<Ticket> SoldTickets = new ArrayList<>();
    @Override
    public void CalculateSalary(float p)// working hours start we end 
    {
      this.setSalary(p*this.getWorking_hours());
    }
    public int getSold_tickets() {
        return this.Sold_Tickets;
    }
    public Caisher(int id, float salary, float working_hours, String Name, String phone_Num) 
    {
        super(id, salary, working_hours, Name, phone_Num);
    }
    
    public boolean SellTicket(int seat,Movie Moviee ,Hall x )
 {      
    if(x.getMovieName()==Moviee.getMovieName()){
        for(Seat y:x.Seats){
            if(seat==y.getSeatNumber()){
                if(y.avilable){
                    y.bookSeat();
                    Ticket z=new Ticket();
                    z.SetMovieName(Moviee.getMovieName());
                    z.setDate(LocalDateTime.now());
                    z.setPrice(Moviee.getPrice());
                    z.setSeatNumber(seat);
                    z.setSerialNumber(seat+x.getHallNumber());
                    this.Sold_Tickets+=1;
                    x.sell_seat();
                    this.SoldTickets.add(z);
                    return true;
                }
                break;
            }
        }
    }
    return false;
 }
}
