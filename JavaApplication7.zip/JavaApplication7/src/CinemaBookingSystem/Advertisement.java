package CinemaBookingSystem;



public class Advertisement 
{
    private String category;
    private float duration;
    private String Adid;

    public Advertisement(String category, float duration) {
        this.category = category;
        this.duration = duration;
    }
public String getid()
{
return this.Adid;
}
public void Setid(String x){
    this.Adid=x;
}
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public float getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
 @Override
    public boolean equals(Object o){
        if(o == this)
            return true;
        Advertisement x=(Advertisement)o;
        if(x.Adid==this.Adid)
            return true;
        return false;
    }
}
