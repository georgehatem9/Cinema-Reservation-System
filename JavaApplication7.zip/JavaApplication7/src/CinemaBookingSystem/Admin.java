
package CinemaBookingSystem;


public class Admin extends Employee
{
    private String Office_Num;
    public Admin(String Office_Num, int id, float salary, float working_hours, String Name, String phone_Num) {
        super(id, salary, working_hours, Name, phone_Num);
        this.Office_Num = Office_Num;
    }
@Override
    public void  CalculateSalary(float p) // 8yrha start time we end time
    {
      this.setSalary(p*this.getWorking_hours());
    }

    public String getOffice_Num() {
        return Office_Num;
    }

    public void setOffice_Num(String Office_Num) {
        this.Office_Num = Office_Num;
    }


}
