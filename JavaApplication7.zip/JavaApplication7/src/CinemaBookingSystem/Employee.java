
package CinemaBookingSystem;


public abstract class Employee extends Person
{
 private int id;
 private float salary;
 private float working_hours;

    public Employee(int id, float salary,float working_hours ,String Name, String phone_Num) {
        super(Name, phone_Num);
        this.id = id;
        this.salary = salary;
        this.working_hours = working_hours;
       
    }

    /**
     *
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o){
        if(o == this)
            return true;
        Employee x=(Employee)o;
        if(x.id==this.id)
            return true;
        return false;
    }

  
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

     public float getWorking_hours() {
        return working_hours;
    }

    public void setWorking_hours(float working_hours) {
        this.working_hours = working_hours;
    }
  public abstract void CalculateSalary(float price_per_hour);
}
