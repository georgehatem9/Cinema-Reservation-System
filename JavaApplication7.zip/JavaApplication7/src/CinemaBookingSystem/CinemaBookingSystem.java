
package CinemaBookingSystem;


public class CinemaBookingSystem 
{

    
    public static void main(String[] args)
    {
        Cinema MyCinema=new Cinema();
        
    }
    
}
