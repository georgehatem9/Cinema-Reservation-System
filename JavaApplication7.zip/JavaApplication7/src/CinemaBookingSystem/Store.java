
package CinemaBookingSystem;


public class Store {
   private String Storeid;
    private float Rent;
    
    public Store(float Rent) {
        this.Rent = Rent;
    }

    public float Total_Rent(float working_hours,float price_per_hour ) // deh 3shan a3r total rent we a5do
    {
        Rent = working_hours*price_per_hour;
        return Rent;
        
    }
    public String getid(){
        return this.Storeid;
    }
    public void setId(String x){
        this.Storeid=x;
    }
 @Override
    public boolean equals(Object o){
        if(o == this)
            return true;
        Store x=(Store)o;
        if(x.Storeid==this.Storeid)
            return true;
        return false;
    }
    public void setRent(float Rent) {
        this.Rent = Rent;
    }
    
    
}
