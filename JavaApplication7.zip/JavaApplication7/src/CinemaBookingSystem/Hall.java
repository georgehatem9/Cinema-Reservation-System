
package CinemaBookingSystem;

import java.util.ArrayList;
import java.util.List;


public class Hall implements Movie_Name {
    private int number;
    private int TotalSeats;
    private int AvailableSeats;
    private String MovieName;
  
    List<Seat> Seats = new ArrayList<Seat>();

    public Hall(int numbers, int TotalSeats, int AvailableSeats) {
        this.number = numbers;
        this.TotalSeats = TotalSeats;
        this.AvailableSeats = AvailableSeats;
    }
public void sell_seat(){
    this.AvailableSeats-=1;
}
    public int getHallNumber() {
        return number;
    }

    public void setHallNumber(int numbers) {
        this.number = numbers;
    }

    public int getTotalSeats() {
        return TotalSeats;
    }

    public void setTotalSeats(int TotalSeats) {
        this.TotalSeats = TotalSeats;
    }

    public int getAvailableSeats() {
        return AvailableSeats;
    }

    public void setAvailableSeats(int AvailableSeats) {
        this.AvailableSeats = AvailableSeats;
    }


    public List<Seat> getSeats() {
        return Seats;
    }

    public void setSeats(List<Seat> Seats) {
        this.Seats = Seats;
    }
    public  void AddtSeats(Seat seatx) {
        
          Seats.add(seatx);
          
        }
   
     public boolean RemoveSeats(Seat seatx, Hall t)
{
        boolean flag = false;
        for(int i=0;i<Seats.size();i++){
        if(Seats.get(i).getSeatNumber()==seatx.getSeatNumber())
        {
        flag=true;
        Seats.remove(i);
        int NEW_TOTAL_SEATS = t.getTotalSeats()-1;
        
        }
        }       
return flag;
}       
  
    //public boolean IncrementSeats (int num){
     //if (num == num ){
         // Seats.add(num);
        //}
//return false;
//}    
     @Override
      public boolean equals(Object o){
        if(o == this)
            return true;
        Hall x=(Hall)o;
        if(x.number==this.number)
            return true;
        return false;
    }
 @Override
    public void SetMovieName(String M)
    {
    MovieName = M;
    }
     @Override
      public String getMovieName(){
          return MovieName;
      }
   
}