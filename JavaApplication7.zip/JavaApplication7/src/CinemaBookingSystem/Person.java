
package CinemaBookingSystem;


public abstract class Person 
{
    private String Name;
    private String phone_Num;

    public Person(String Name, String phone_Num) 
    {
        this.Name = Name;
        this.phone_Num = phone_Num;
    }

  
}
